﻿<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";	

$conn = @mysqli_connect($servername, $username, $password, $db);
if (!$conn){
	die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");		
}

if (isset($_REQUEST["btnDisplay"]))
{	
	
	$mssv = $_REQUEST["mssv"];
	
	$query = "SELECT * FROM SINHVIEN WHERE MSSV=$mssv";
	
	$result = mysql_query($query, $link);	
	
	if (!$result)
	{
		print "failed to open the $table !";	
	}
	else
	{
		if ($row = mysql_fetch_row($result))
		{
			$hoten= $row[1];
			$ngaysinh = $row[2];
			$diachi = $row[3];
			$makhoa = $row[4];		
		}
		else
		{
			echo "Mã Sinh Viên không tồn tại !!!";			
		}	
	}	
	
}

if (isset($_REQUEST["btnUpdate"]))
{
	$hoten= $_REQUEST["HoTen"];
	$ngaysinh = $_REQUEST["NgaySinh"];
	$diachi = $_REQUEST["DiaChi"];
	$malop = $_REQUEST["MaLop"];
	$mahs = $_REQUEST["MaHS"];
	
	$query = "Update HOCSINH Set TenHS = '$hoten', NgaySinh='$ngaysinh', diachi='$diachi', malop=$malop WHERE mahs=$mahs";
	
	$result = mysql_query($query, $link);	
	
	echo "Query for excuting : $query <br/>";
	
	echo "Result: <br/>";
	if(mysql_errno() != 0)
	{
		echo "mysql_error(): ".mysql_error()."<br/>";	
		echo "mysql_errno(): ".mysql_errno()."<br/>";
	}
	else
		echo "Update an record successfully !<br/>";
	
	
}
?>


<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

			<title></title>
	</head>
	<body>
		<form action="HienThiVaCapNhatHocSinh.php" method="get">
		<table>			
            <tr>
                <td>Mã học sinh</td>
                <td><input id="Text1" name="MaHS" type="text" value="<?php echo $mahs; ?>"/></td>
            </tr>
            <tr>
                <td>Họ và tên</td>
                <td><input id="Text2" name="HoTen" type="text"  value="<?php echo $hoten; ?>"/></td>                   
            </tr>
            <tr>
                <td>Ngày Sinh</td>
                <td><input id="Text3" name="NgaySinh" type="text"  value="<?php echo $ngaysinh; ?>"/></td>
            </tr>
            <tr>
                <td>Địa chỉ</td>
                <td><input id="Text4" name="DiaChi" type="text"  value="<?php echo $diachi; ?>"/></td>
            </tr>
            <tr>
                <td>Mã Lớp</td>
                <td><input id="Text5" name="MaLop" type="text"  value="<?php echo $malop; ?>"/></td>
            </tr>           			     
			
         </table>
		<input id="Submit4" type="submit" name="btnUpdate" value="Update" />     
		<input id="Submit5" type="submit" name="btnDelete" value="Delete" />  
		<a href="HocSinh.htm">Quay lại</a>
		
<?php
if (isset($_REQUEST["btnDelete"]))
{
	$mahs = $_REQUEST["MaHS"];
	
	$query = "DELETE FROM $table WHERE mahs=$mahs";
	
	$result = mysql_query($query, $link);	
	
	if(mysql_errno() != 0)
	{
		echo "mysql_error(): ".mysql_error()."<br/>";	
		echo "mysql_errno(): ".mysql_errno()."<br/>";
	}
	else
		echo "Delete record successfully !<br/>";
}
?>
<?php
mysql_close( $link );
?>
		</form>
	</body>
</html>
