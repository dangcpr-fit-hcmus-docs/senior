-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 26, 2019 at 09:52 AM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `SinhVienDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `SINHVIEN`
--

CREATE TABLE `SINHVIEN` (
  `MSSV` mediumint(9) NOT NULL,
  `HoTen` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NgaySinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DiaChi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DienThoai` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MaKhoa` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SINHVIEN`
--

INSERT INTO `SINHVIEN` (`MSSV`, `HoTen`, `NgaySinh`, `DiaChi`, `DienThoai`, `MaKhoa`) VALUES
(1712001, 'Jael Humphrey', '1999-12-09', 'Terme', '059-701-8229', 'HHOC'),
(1712002, 'Celeste Rich', '1999-12-21', 'Chatillon', '031-767-0828', 'TOAN'),
(1712003, 'Tiger Harris', '1999-01-15', 'Gasp�', '077-681-6478', 'CNTT'),
(1712004, 'Demetrius Huffman', '1999-04-21', 'Contagem', '075-411-2924', 'HHOC'),
(1712005, 'Bree Rowe', '1999-04-21', 'Satna', '098-393-7234', 'CNTT'),
(1712006, 'Daquan Hansen', '1999-07-09', 'Fort Worth', '029-140-6405', 'HHOC'),
(1712007, 'Carter Warner', '1999-05-22', 'Shreveport', '057-384-8554', 'CNTT'),
(1712008, 'Murphy Houston', '1999-12-15', 'Miami', '084-406-4961', 'TOAN'),
(1712009, 'Sage Mcknight', '1999-03-09', 'Mount Gambier', '075-306-8652', 'HHOC'),
(1712010, 'Venus Robbins', '1999-09-15', 'Hamilton', '008-741-8575', 'HHOC'),
(1712011, 'Cameran Hawkins', '1999-01-22', 'Neubrandenburg', '016-586-1742', 'TOAN'),
(1712012, 'Reed Ashley', '1999-12-26', 'Enterprise', '062-279-7740', 'CNTT'),
(1712013, 'Jamalia Foreman', '1999-11-03', 'Eluru', '063-862-0152', 'HHOC'),
(1712014, 'Lana Conner', '1999-11-01', 'Chetwynd', '044-923-3888', 'HHOC'),
(1712015, 'Uma Tucker', '1999-04-15', 'Asbestos', '055-829-4173', 'TOAN'),
(1712016, 'Guy Graham', '1999-06-30', 'Ceyhan', '099-859-2362', 'TOAN'),
(1712017, 'Rogan Puckett', '1999-01-21', 'Randazzo', '076-564-2500', 'TOAN'),
(1712018, 'Winter Carson', '1999-07-10', 'Collines-de-l\'Outaouais', '020-735-4259', 'CNTT'),
(1712019, 'Hayfa Pittman', '1999-01-21', 'Paço do Lumiar', '093-892-6371', 'CNTT'),
(1712020, 'Nicole England', '1999-10-12', 'Huntley', '052-608-7448', 'HHOC'),
(1712021, 'Willa Gordon', '1999-08-13', 'Dillingen', '070-535-2262', 'TOAN'),
(1712022, 'Iris Burke', '1999-10-01', 'Nurallao', '054-622-1733', 'HHOC'),
(1712023, 'Lacey Lang', '1999-08-14', 'Knighton', '046-550-4063', 'HHOC'),
(1712024, 'Kimberley Sanchez', '1999-11-14', 'Comano', '023-131-6425', 'CNTT'),
(1712025, 'Cameron Guzman', '1999-09-06', 'Bath', '050-594-4783', 'TOAN'),
(1712026, 'Hiram Matthews', '1999-07-19', 'Port Moody', '044-381-6593', 'TOAN'),
(1712027, 'Adrian Tyson', '1999-02-23', 'New Galloway', '008-768-4566', 'CNTT'),
(1712028, 'Marshall Mclaughlin', '1999-05-28', 'Daman', '058-539-6273', 'HHOC'),
(1712029, 'Cain Gillespie', '1999-12-21', 'New Plymouth', '094-298-2956', 'HHOC'),
(1712030, 'Patrick Pratt', '1999-01-29', 'Cagliari', '019-315-0512', 'HHOC'),
(1712031, 'Marcia Hunt', '1999-12-09', 'Calice al Cornoviglio', '021-604-3803', 'CNTT'),
(1712032, 'Yasir Serrano', '1999-01-30', 'Ingolstadt', '001-346-3508', 'CNTT'),
(1712033, 'Diana Sweet', '1999-04-05', 'San Rafael', '062-297-2772', 'TOAN'),
(1712034, 'Bradley Sampson', '1999-01-31', 'Maracanaú', '070-412-4307', 'TOAN'),
(1712035, 'Nevada Solis', '1999-02-10', 'Saintes', '067-865-1624', 'CNTT'),
(1712036, 'Chaim Patrick', '1999-06-18', 'Purén', '075-153-1263', 'HHOC'),
(1712037, 'Gary Parker', '1999-05-10', 'Fredericton', '056-366-7498', 'HHOC'),
(1712038, 'Kieran Ross', '1999-02-06', 'Norfolk County', '056-489-5666', 'TOAN'),
(1712039, 'Ishmael Parker', '1999-05-10', 'Halisahar', '025-421-0597', 'HHOC'),
(1712040, 'Aphrodite Singleton', '1999-10-31', 'Offenbach am Main', '071-982-3289', 'HHOC'),
(1712041, 'Zelda Underwood', '1999-04-02', 'New Quay', '044-481-1499', 'TOAN'),
(1712042, 'Hyatt Herman', '1999-07-30', 'Murray Bridge', '058-432-6086', 'HHOC'),
(1712043, 'Lani Ellison', '1999-10-23', 'Arendonk', '056-856-1416', 'HHOC'),
(1712044, 'Gemma Rich', '1999-10-22', 'Manukau', '029-253-3596', 'CNTT'),
(1712045, 'Dorothy Snider', '1999-07-04', 'Masone', '069-782-9435', 'CNTT'),
(1712046, 'Xanthus Gay', '1999-03-05', 'l\'Ecluse', '008-685-3774', 'TOAN'),
(1712047, 'Ethan Jacobson', '1999-02-28', 'Pointe-Claire', '068-611-4524', 'CNTT'),
(1712048, 'Nissim Salazar', '1999-05-05', 'Oostkamp', '072-973-1487', 'TOAN'),
(1712049, 'Cara Bailey', '1999-03-20', 'Milmort', '096-572-0641', 'TOAN'),
(1712050, 'Dante Carroll', '1999-12-19', 'Borriana', '062-499-1610', 'TOAN'),
(1712051, 'Naida West', '1999-07-11', 'Cleveland', '019-710-7291', 'HHOC'),
(1712052, 'Zelda Fox', '1999-04-10', 'Cape Breton Island', '057-931-9636', 'CNTT'),
(1712053, 'Zenia Melendez', '1999-05-11', 'Haddington', '038-869-3794', 'CNTT'),
(1712054, 'Kaseem Savage', '1999-11-05', 'Verrebroek', '088-809-8832', 'HHOC'),
(1712055, 'Aspen Zamora', '1999-07-18', 'Tailles', '084-150-6034', 'TOAN'),
(1712056, 'Uriel Alford', '1999-02-02', 'Gatineau', '061-610-9179', 'CNTT'),
(1712057, 'Jennifer Valentine', '1999-05-02', 'Hall in Tirol', '077-705-7280', 'CNTT'),
(1712058, 'Iona Bush', '1999-12-22', 'Moerzeke', '016-419-2808', 'HHOC'),
(1712059, 'Aquila Hall', '1999-05-29', 'Gentinnes', '088-379-6137', 'TOAN'),
(1712060, 'Joshua Murphy', '1999-08-24', 'Emarèse', '020-162-1168', 'CNTT'),
(1712061, 'Nathan Campos', '1999-03-07', 'Las Vegas', '088-935-1318', 'TOAN'),
(1712062, 'Maisie Dominguez', '1999-03-20', 'Pellizzano', '091-066-0759', 'CNTT'),
(1712063, 'Arden Little', '1999-05-17', 'Zellik', '049-785-2827', 'CNTT'),
(1712064, 'Brennan Perez', '1999-01-17', 'Strathcona County', '064-137-6775', 'CNTT'),
(1712065, 'Yoko Mendez', '1999-08-07', 'Valparaíso', '042-200-5925', 'CNTT'),
(1712066, 'Justine Gregory', '1999-07-05', 'Zaltbommel', '048-201-3202', 'CNTT'),
(1712067, 'Chastity Hopkins', '1999-05-24', 'Dole', '062-114-7720', 'HHOC'),
(1712068, 'Rachel Reese', '1999-09-21', 'Guardia Sanframondi', '016-513-7458', 'CNTT'),
(1712069, 'Anthony Collier', '1999-04-10', 'Raymond', '049-385-2585', 'TOAN'),
(1712070, 'Anne Rose', '1999-09-26', 'Casnate con Bernate', '067-858-0667', 'HHOC'),
(1712071, 'Kylan Walton', '1999-07-18', 'Renlies', '096-440-0787', 'CNTT'),
(1712072, 'Randall Scott', '1999-04-01', 'Wokingham', '089-936-1985', 'HHOC'),
(1712073, 'Oren Padilla', '1999-04-09', 'Wabamun', '080-258-1424', 'TOAN'),
(1712074, 'Dominic Shelton', '1999-10-28', 'Clovenfords', '097-329-7489', 'CNTT'),
(1712075, 'Amber Ball', '1999-06-13', 'Graneros', '098-811-7101', 'CNTT'),
(1712076, 'Charde Blackwell', '1999-05-07', 'Elx', '057-332-1274', 'HHOC'),
(1712077, 'Darius Williams', '1999-02-14', 'Tuticorin', '089-561-6752', 'TOAN'),
(1712078, 'Phillip Reynolds', '1999-03-22', 'Devonport', '040-966-7137', 'HHOC'),
(1712079, 'Denton Lambert', '1999-11-11', 'Elbląg', '017-537-1831', 'TOAN'),
(1712080, 'April Bryant', '1999-08-20', 'Sagar', '071-327-9048', 'HHOC'),
(1712081, 'Aristotle Barrett', '1999-02-03', 'Labrecque', '037-449-3909', 'CNTT'),
(1712082, 'Tiger Morgan', '1999-10-06', 'Lokeren', '019-971-9948', 'CNTT'),
(1712083, 'Orlando Dawson', '1999-12-10', 'Monacilioni', '043-450-9058', 'HHOC'),
(1712084, 'Vera Olson', '1999-01-07', 'Oelegem', '078-735-4628', 'TOAN'),
(1712085, 'Griffin Mcintosh', '1999-05-04', 'Isnes', '091-161-2159', 'HHOC'),
(1712086, 'Abraham Schroeder', '1999-07-06', 'Meldert', '025-023-9564', 'CNTT'),
(1712087, 'Eliana Huffman', '1999-06-09', 'Hualpén', '059-600-5030', 'CNTT'),
(1712088, 'Lacota Benjamin', '1999-04-04', 'Flensburg', '047-613-6904', 'HHOC'),
(1712089, 'Harding Anderson', '1999-09-15', 'Sandy', '042-209-0310', 'HHOC'),
(1712090, 'Keely Jackson', '1999-12-30', 'Stintino', '001-682-3227', 'CNTT'),
(1712091, 'Velma Rivas', '1999-01-25', 'Qutubullapur', '001-791-4598', 'TOAN'),
(1712092, 'Cleo Meyers', '1999-03-22', 'Pitt Meadows', '092-433-8558', 'TOAN'),
(1712093, 'Xander Fuller', '1999-12-05', 'Frankfurt am Main', '028-985-3506', 'TOAN'),
(1712094, 'Otto Walls', '1999-07-06', 'Thionville', '011-690-3867', 'CNTT'),
(1712095, 'Emery Roy', '1999-05-24', 'Villers-la-Bonne-Eau', '041-011-0435', 'CNTT'),
(1712096, 'Prescott Ward', '1999-04-08', 'Bad Neuenahr-Ahrweiler', '064-790-1530', 'HHOC'),
(1712097, 'Ayanna Griffin', '1999-02-12', 'Anderlecht', '046-013-7394', 'TOAN'),
(1712098, 'Slade Macdonald', '1999-06-28', 'Bruderheim', '043-582-0914', 'HHOC'),
(1712099, 'Porter Kline', '1999-09-24', 'Newport', '006-521-4394', 'HHOC'),
(1712100, 'Inga Todd', '1999-04-02', 'Calgary', '076-002-5146', 'HHOC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `SINHVIEN`
--
ALTER TABLE `SINHVIEN`
  ADD PRIMARY KEY (`MSSV`);
