﻿<HTML>
	<HEAD>
		<TITLE></TITLE>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="css/table.css"/>
	</HEAD>
	<BODY>
	    <?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";

if(isset($_REQUEST["btnTestConnection"]))
{		
	$conn = @mysqli_connect($servername, $username, $password, $db);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");		
	}
	echo "Connected successfully";
	mysqli_close($conn);
}
	
// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if (!$conn) {	
	die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}


if(isset($_REQUEST["MSSV"]))
{
	echo "Delete ...". $_REQUEST['MSSV'];
	if (isset($_REQUEST['MSSV']))
	{
		$MSSV = $_REQUEST['MSSV'];
		$query = "DELETE FROM SINHVIEN WHERE MSSV='$MSSV'";
		echo $query;
		if (@mysqli_query($conn, $query))
		{
			echo "Xoá thành công !!!";
		}
		else {
			echo "Lỗi: " . $query . "<br>" . mysqli_error($conn);
		}
	}
}
if(isset($_REQUEST["btnDeleteAll"]))
{
	$deleted_ids = implode("','", $_REQUEST['MSSVList']);	
	$query = "DELETE FROM SINHVIEN WHERE MSSV IN ('$deleted_ids')";
	echo "query: $query";

	if (@mysqli_query($conn, $query))
		{
			echo "Xoá thành công !!!";
		}
		else {
			echo "Lỗi: " . $query . "<br>" . mysqli_error($conn);
		}
}


$sql = "SELECT * FROM SINHVIEN";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	// output data of each row
	echo "<form method='GET'>";
	echo "<td><input type='submit' value='Delete selected rows' name='btnDeleteAll'/></td>";

	echo "<table class='myTable' border='1'>";
	echo "<tr>";
	echo "<th>&nbsp;</th>";
	echo "<th>MSSV</th>";
	echo "<th>Họ tên</th>";		
	echo "<th>Ngày sinh</th>";		
	echo "<th>Địa chỉ</th>";		
	echo "<th>Điện thoại</th>";		
	echo "<th>Mã khoa</th>";		
	echo "<th>";
	echo "</tr>";

	while($row = mysqli_fetch_assoc($result)) 		
	{
		$mssv = $row["MSSV"];
		$hoten= $row["HoTen"];
		$ngaysinh = $row["NgaySinh"];
		$diachi = $row["DiaChi"];
		$dienthoai = $row["DienThoai"];
		$makhoa = $row["MaKhoa"];
		// echo "<form action='XemDanhSachHocSinh.php' method='GET'>";
		echo "<tr>";
		echo "<td><input type='checkbox' name='MSSVList[]' value='$mssv'/></td>";
		echo "<td>$mssv</td>";
		echo "<td>$hoten</td>";		
		echo "<td>$ngaysinh</td>";		
		echo "<td>$diachi</td>";		
		echo "<td>$dienthoai</td>";		
		echo "<td>$makhoa</td>";		
		echo "<td>";
		// echo "<input type='hidden' name='MSSV' value='$mssv'/>";
		// echo "<input type='submit' value='Delete' />";
		echo "<a href='XemDanhSachSinhVien.php?MSSV=$mssv'> Delete</a>";
		echo "</td>";
		echo "</tr>";
		
	}
	
	echo "</table>";
	echo "</form>";			
} else {
	echo "0 results";
}

mysqli_close($conn);

	

?>
		<a href="TrangChu.htm">Quay lại</a>

	</BODY>
</HTML>
