
<?php
// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if (!$conn) {	
	die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}
$sql = "SELECT * FROM SINHVIEN";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	// output data of each row
	while($row = mysqli_fetch_assoc($result)) 		
	{
        $mssv = $row["MSSV"];		
        ...
	}
} 
mysqli_close($conn);
?>


<?php
// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if (!$conn) {	
	die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}
$query = "INSERT INTO SINHVIEN values ($mssv, '$hoten', '$ngaysinh', '$diachi', '$dienthoai', '$makhoa')";

echo "Step 3. Excute the query";
echo "Query for excuting : $query <br/>";
if (@mysqli_query($conn, $query))
{
	echo "New record created successfully";
}
else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>

