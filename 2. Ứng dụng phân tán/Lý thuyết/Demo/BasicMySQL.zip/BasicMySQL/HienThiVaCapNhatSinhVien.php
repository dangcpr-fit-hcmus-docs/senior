﻿<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";	

$conn = mysqli_connect($servername, $username, $password, $db);
if (!$conn) {	
	die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}

if (isset($_REQUEST["mssv"]))
{	
	
	$mssv = $_REQUEST["mssv"];		
	$query = "SELECT * FROM SINHVIEN WHERE MSSV=$mssv";
	print $query;
	
	$result = mysqli_query($conn, $query);	
	
	if (!$result)
	{
		print "failed to open the table !";	
	}
	else
	{
		if ($row = mysqli_fetch_row($result))
		{
			$hoten= $row[1];
			$ngaysinh = $row[2];
			$diachi = $row[3];
			$makhoa = $row[4];		
		}
		else
		{
			echo "Mã Sinh Viên không tồn tại !!!";			
		}	
	}	
	
}

if (isset($_REQUEST["btnUpdate"]))
{
	$hoten= $_REQUEST["HoTen"];
	$ngaysinh = $_REQUEST["NgaySinh"];
	$diachi = $_REQUEST["DiaChi"];
	$makhoa = $_REQUEST["MaKhoa"];
	$mssv = $_REQUEST["MSSV"];
	$query = "Update SINHVIEN Set HoTen = '$hoten', NgaySinh='$ngaysinh', diachi='$diachi', MaKhoa=$makhoa WHERE MSSV=$masv";
	$result = mysqli_query($conn, $query);	
	
	echo "Query for excuting : $query <br/>";
	
	echo "Result: <br/>";
	if(mysql_errno() != 0)
	{
		echo "mysqli_error(): ".mysqli_error()."<br/>";	
		echo "mysqli_errno(): ".mysqli_errno()."<br/>";
	}
	else
		echo "Update an record successfully !<br/>";	
}
?>


<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

			<title></title>
	</head>
	<body>
		<form action="." method="get">
		<table>			
            <tr>
                <td>Mã SV</td>
                <td><input name="MSSV" type="text" value="<?php echo $mssv; ?>"/></td>
            </tr>
            <tr>
                <td>Họ và tên</td>
                <td><input name="HoTen" type="text"  value="<?php echo $hoten; ?>"/></td>                   
            </tr>
            <tr>
                <td>Ngày Sinh</td>
                <td><input name="NgaySinh" type="text"  value="<?php echo $ngaysinh; ?>"/></td>
            </tr>
            <tr>
                <td>Địa chỉ</td>
                <td><input name="DiaChi" type="text"  value="<?php echo $diachi; ?>"/></td>
            </tr>
            <tr>
                <td>Mã Khoa</td>
                <td><input name="MaKhoa" type="text"  value="<?php echo $makhoa; ?>"/></td>
            </tr>           			     
			
         </table>
		<input type="submit" name="btnUpdate" value="Update" />     
		<input type="submit" name="btnDelete" value="Delete" />  
		<a href="/BasicMySQL">Quay lại</a>
		
<?php
if (isset($_REQUEST["btnDelete"]))
{
	$masv = $_REQUEST["MSSV"];
	
	$query = "DELETE FROM SINHVIEN WHERE MSSV=$masv";
	
	$result = mysql_query($query, $link);	
	
	if(mysql_errno() != 0)
	{
		echo "mysql_error(): ".mysql_error()."<br/>";	
		echo "mysql_errno(): ".mysql_errno()."<br/>";
	}
	else
		echo "Delete record successfully !<br/>";
}
?>
<?php
mysqli_close( $conn );
?>
		</form>
	</body>
</html>
