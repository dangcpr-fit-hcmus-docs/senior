<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";	

echo "Step 1. Connect to server & connect to database ! <br/>";
$conn = @mysqli_connect($servername, $username, $password, $db);
if (!$conn){
	die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");		
}

$mssv = $_REQUEST["MSSV"];
$hoten = $_REQUEST["HoTen"];
$ngaysinh = $_REQUEST["NgaySinh"];
$diachi = $_REQUEST["DiaChi"];
$dienthoai = $_REQUEST["DienThoai"];
$makhoa = $_REQUEST["MaKhoa"];

$query = "INSERT INTO SINHVIEN values ($mssv, '$hoten', '$ngaysinh', '$diachi', '$dienthoai', '$makhoa')";

echo "Step 3. Excute the query";
echo "Query for excuting : $query <br/>";
if (@mysqli_query($conn, $query))
{
	echo "New record created successfully";
}
else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}

mysqli_close( $conn );

?>

<a href="TrangChu.html">Quay lại</a>