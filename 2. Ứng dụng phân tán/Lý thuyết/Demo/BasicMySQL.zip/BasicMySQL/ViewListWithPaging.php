﻿<HTML>
	<HEAD>
		<TITLE></TITLE>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />		
	</HEAD>
	<BODY>
		<h1>Paging</h1>
<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";
$pagesize = 10;
$currentpage = 1;

if (isset($_REQUEST["currentpage"]))
	$currentpage = $_REQUEST["currentpage"];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if (!$conn) {	
	die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}

$start = ($currentpage-1) * $pagesize;

$query = "SELECT * FROM SINHVIEN LIMIT $start, $pagesize";

$result = mysqli_query($conn, $query);	

if (mysqli_num_rows($result) > 0) {

	echo "<table border='1'>";
	while ($row = mysqli_fetch_row($result))
	{
		$mssv = $row[0];
		$hoten= $row[1];
		$ngaysinh = $row[2];
		$diachi = $row[3];
		$dienthoai = $row[4];
		$makhoa = $row[5];
		
		echo "<tr>";
		echo "<td>$mssv</td>";
		echo "<td>$hoten</td>";		
		echo "<td>$ngaysinh</td>";		
		echo "<td>$diachi</td>";		
		echo "<td>$dienthoai</td>";		
		echo "<td>$makhoa</td>";		
		echo "</tr>";			
	}
	echo "</table>";
}	

$query = "SELECT count(*) as NUMROW FROM SINHVIEN";
$result = mysqli_query($conn, $query);	
$row = mysqli_fetch_array($result);
$numrow = $row["NUMROW"];
$numpage = ceil($numrow / ($pagesize*1.0));

echo "Total of rows is: $numrow <br/>";
echo "Number of page is: $numpage <br/>";
$self = $_SERVER['PHP_SELF'];

$nav = "";

//Style 1
for($i = 1; $i <= $numpage; $i ++)
{
	if ($i == $currentpage)
		$nav .= $i;
	else
		$nav .= "<a href=\"$self?currentpage=$i\">$i</a> "; 
}

echo "<h2>Style 1: </h2>";
echo $nav;


//Style 
if ($currentpage > 1)
{
	$page = $currentpage - 1;
	$first = "<a href='$self?currentpage=1'>[First]</a> ";
	$prev = "<a href='$self?currentpage=$page'>[Previous]</a> ";
}
else
{
	$first = "[First]";
	$prev = "[Previous]";
}


if ($currentpage < $numpage)
{
	$page = $currentpage + 1;
	$next = "<a href='$self?currentpage=$page'>[Next]</a> ";
	$last = "<a href='$self?currentpage=$numpage'>[Last]</a> ";
}
else
{
	$next = "[Next]";
	$last = "[Last]";
}

echo "<h2>Style 2: </h2>";
echo $first . $prev . " Page ". $currentpage." ".$next . $last;

mysqli_close( $conn );

?>
	</BODY>
</HTML>
