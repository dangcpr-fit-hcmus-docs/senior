<html>
    <HEAD>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<TITLE>Demo Lập trình với CSDL</TITLE>
	</HEAD>
    <body>
        <h1>Danh sách sinh viên phân trang</h1> 
        <?php
            $self = $_SERVER['PHP_SELF'];
            $servername = "localhost";
            $username = "root";
            $password = "root";
            $db = "SinhVienDB";

            $pagesize = 10;
            $currentpage = 1;
            if (isset($_REQUEST["page"]))
                $currentpage = $_REQUEST["page"];

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $db);
            // Check connection
            if (!$conn) {	
                die("Lỗi kết nối CSDL: " . mysqli_connect_error());
            }

            if (isset($_REQUEST['deleted']))
            {
                $deleted = $_REQUEST['deleted'];
                $query = "DELETE FROM SINHVIEN WHERE MSSV='$deleted'";                
                if (@mysqli_query($conn, $query))
                {
                    echo "Xoá thành công $deleted";
                }
                else {
                    echo "Lỗi: " . $query . "<br>" . mysqli_error($conn);
                }
            }

            $start = ($currentpage-1) * $pagesize;
            $sql = "SELECT * FROM SINHVIEN LIMIT $start, $pagesize" ;
            $result = mysqli_query($conn, $sql);
            // echo mysqli_num_rows($result);
            echo "<table border='1'>";
            echo "<tr>";
            echo "<th></th>";
            echo "<th>STT</th>";
            echo "<th>MSSV</th>";
            echo "<th>Họ tên</th>";
            echo "<th>Ngày sinh</th>";
            echo "<th>Địa chỉ</th>";
            echo "<th>Điện thoại</th>";
            echo "<th>Mã khoa</th>";
            echo "<th>Xoá</th>";
            echo "</tr>";
            $stt = $start + 1;
            if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) 		
	            {   
                    $mssv = $row["MSSV"];
                    $hoten = $row["HoTen"];
                    $ngaysinh = $row["NgaySinh"];
                    $diachi = $row["DiaChi"];
                    $dienthoai = $row["DienThoai"];
                    $makhoa = $row["MaKhoa"];
                    echo "<tr>";
                    echo "<td><input type='checkbox'/></td>";
                    echo "<td>$stt</td>";
                    echo "<td>$mssv</td>";
                    echo "<td>$hoten</td>";
                    echo "<td>$ngaysinh</td>";
                    echo "<td>$diachi</td>";
                    echo "<td>$dienthoai</td>";
                    echo "<td>$makhoa</td>";
                    echo "<td><a href='XemDanhSachSinhVien.php?deleted=$mssv'>Xoá</a></td>";
                    echo "</tr>";
                    $stt += 1;
                }
            }
            echo "</table>";

            $query = "SELECT count(*) as NUMROW FROM SINHVIEN";
            $result = mysqli_query($conn, $query);	
            $row = mysqli_fetch_array($result);
            $numrow = $row["NUMROW"];
            $numpage = ceil($numrow / ($pagesize*1.0));
            
            for ($i = 1; $i <= $numpage; $i ++)
            {
                if ($i != $currentpage)
                    echo "<a href='$self?page=$i'>$i</a> ";
                else
                    echo "<strong>$i</strong>";
            }

            echo "<hr/>";
            //Style 
            if ($currentpage > 1)
            {
                $page = $currentpage - 1;
                $first = "<a href='$self?page=1'>[First]</a> ";
                $prev = "<a href='$self?page=$page'>[Previous]</a> ";
            }
            else
            {
                $first = "[First]";
                $prev = "[Previous]";
            }


            if ($currentpage < $numpage)
            {
                $page = $currentpage + 1;
                $next = "<a href='$self?page=$page'>[Next]</a> ";
                $last = "<a href='$self?page=$numpage'>[Last]</a> ";
            }
            else
            {
                $next = "[Next]";
                $last = "[Last]";
            }
            echo $first . $prev . " Page ". $currentpage." ".$next . $last;
            mysqli_close($conn);

        ?>   
    </body>
</html>