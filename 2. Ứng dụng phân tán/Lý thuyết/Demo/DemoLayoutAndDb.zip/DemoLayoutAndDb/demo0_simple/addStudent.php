<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add student</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        /* Style the header */
        .header {
            background-color: #f1f1f1;
            padding: 10px;
            text-align: center;
            font-size: 35px;
        }

        /* Create three equal columns that floats next to each other */
        .column {
            float: left;
            width: 100%;
            padding: 10px;
            height: 300px; /* Should be removed. Only for demonstration */
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        /* Style the footer */
        .footer {
            background-color: #f1f1f1;
            padding: 10px;
            text-align: center;
        }

    </style>
</head>
<body>
<div class="header">
    <h2>Header</h2>
</div>

<div class="row">
    <div class="column" >
        <h1>Thêm sinh viên</h1>
        <form action="addStudent.php" method ="get">
            <table>
                <tr>
                    <td>Mã sinh viên</td>
                    <td><input name="MSSV" type="text" /></td>
                </tr>
                <tr>
                    <td>Họ và tên</td>
                    <td><input name="HoTen" type="text" /></td>
                </tr>
                <tr>
                    <td>Ngày Sinh</td>
                    <td><input name="NgaySinh" type="text" /></td>
                </tr>
                <tr>
                    <td>Địa chỉ</td>
                    <td><input name="DiaChi" type="text" /></td>
                </tr>
                <tr>
                    <td>Điện thoại</td>
                    <td><input name="DienThoai" type="text" /></td>
                </tr>
                <tr>
                    <td>Mã Khoa</td>
                    <td><input name="MaKhoa" type="text" /></td>
                </tr>
            </table>
            <input type="submit" value="Thêm sinh viên" />
        </form>

        <?php
        if (isset($_REQUEST["MSSV"]))
        {
            $servername = "localhost";
            $username = "root";
            $password = "root";
            $db = "SinhVienDB";

            echo "Step 1. Connect to server & connect to database ! <br/>";
            $conn = @mysqli_connect($servername, $username, $password, $db);
            if (!$conn){
                die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");
            }
            echo "Step 2. Read sent data";
            $mssv = $_REQUEST["MSSV"];
            $hoten = $_REQUEST["HoTen"];
            $ngaysinh = $_REQUEST["NgaySinh"];
            $diachi = $_REQUEST["DiaChi"];
            $dienthoai = $_REQUEST["DienThoai"];
            $makhoa = $_REQUEST["MaKhoa"];

            $query = "INSERT INTO SINHVIEN values ($mssv, '$hoten', '$ngaysinh', '$diachi', '$dienthoai', '$makhoa')";

            echo "Step 3. Excute the query";
            echo "Query for excuting : $query <br/>";
            if (@mysqli_query($conn, $query))
            {
                echo "New record created successfully";
            }
            else {
                echo "Error: " . $query . "<br>" . mysqli_error($conn);
            }

            mysqli_close( $conn );
        }
        ?>
    </div>
</div>

<div class="footer">
    <p>Demo form HTML</p>
</div>
</body>
</html>
