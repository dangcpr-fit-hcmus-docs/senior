
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.1/assets/img/favicons/favicon.ico">

    <title>Dashboard Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.1/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="https://getbootstrap.com/docs/4.1/examples/dashboard/#">Demo</a>
    <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="#">Sign out</a>
        </li>
    </ul>
</nav>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            Trang chủ
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="add.php">
                            Thêm sinh viên
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="list.php">
                            List Students
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">
                            Search Students
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Add student</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                </div>
            </div>
            <div>
                <form action="add.php" method="get">
                    <div class="form-group">
                        <label>MSSV</label>
                        <input type="text" name="MSSV" class="form-control" placeholder="Hãy nhập MSSV ở đây">
                    </div>
                    <div class="form-group">
                        <label>Họ và tên</label>
                        <input type="text" name="HoTen" class="form-control" placeholder="Họ và tên">
                    </div>
                    <div class="form-group">
                        <label>Ngày Sinh</label>
                        <input type="text" name="NgaySinh" class="form-control" placeholder="Ngày Sinh">
                    </div>

                    <div class="form-group">
                        <label>Địa chỉ</label>
                        <input type="text" name="DiaChi" class="form-control" placeholder="Địa chỉ">
                    </div>

                    <div class="form-group">
                        <label>Điện thoại</label>
                        <input type="text" name="DienThoai" class="form-control" placeholder="Điện thoại">
                    </div>
                    <div class="form-group">
                        <label>Mã khoa</label>
                        <input type="text" name="MaKhoa" class="form-control" placeholder="Mã khoa">
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm sinh viên mới</button>
                </form>
            </div>

            <?php
                if (isset($_REQUEST["MSSV"]))
                {
                    $servername = "localhost";
                    $username = "root";
                    $password = "root";
                    $db = "SinhVienDB";

                    echo "Step 1. Connect to server & connect to database ! <br/>";
                    $conn = @mysqli_connect($servername, $username, $password, $db);
                    if (!$conn){
                        die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");
                    }
                    echo "Step 2. Read sent data";
                    $mssv = $_REQUEST["MSSV"];
                    $hoten = $_REQUEST["HoTen"];
                    $ngaysinh = $_REQUEST["NgaySinh"];
                    $diachi = $_REQUEST["DiaChi"];
                    $dienthoai = $_REQUEST["DienThoai"];
                    $makhoa = $_REQUEST["MaKhoa"];

                    $query = "INSERT INTO SINHVIEN values ($mssv, '$hoten', '$ngaysinh', '$diachi', '$dienthoai', '$makhoa')";

                    echo "Step 3. Excute the query";
                    echo "Query for excuting : $query <br/>";
                    if (@mysqli_query($conn, $query))
                    {
                        echo "New record created successfully";
                    }
                    else {
                        echo "Error: " . $query . "<br>" . mysqli_error($conn);
                    }

                    mysqli_close( $conn );
                }
            ?>
        </main>
    </div>
</div>
</body>
</html>

