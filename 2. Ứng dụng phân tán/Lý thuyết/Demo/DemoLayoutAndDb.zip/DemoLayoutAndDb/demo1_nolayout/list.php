
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.1/assets/img/favicons/favicon.ico">

    <title>Dashboard Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.1/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="https://getbootstrap.com/docs/4.1/examples/dashboard/#">Demo</a>
    <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="#">Sign out</a>
        </li>
    </ul>
</nav>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add.php">
                            Add Student
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="list.php">
                            List Students
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">
                            Search Students
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">List all students</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                </div>
            </div>
            <div>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "root";
                $db = "SinhVienDB";

                if(isset($_REQUEST["btnTestConnection"]))
                {
                    $conn = @mysqli_connect($servername, $username, $password, $db);
                    // Check connection
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");
                    }
                    echo "Connected successfully";
                    mysqli_close($conn);
                }

                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $db);
                // Check connection
                if (!$conn) {
                    die("Lỗi kết nối CSDL: " . mysqli_connect_error());
                }

                $sql = "SELECT * FROM SINHVIEN";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    // output data of each row
                    echo "<form method='GET'>";

                    echo "<table class='table'>";
                    echo "<tr>";
                    echo "<td>stt</td>";
                    echo "<td>mssv</td>";
                    echo "<td>hoten</td>";
                    echo "<td>ngaysinh</td>";
                    echo "<td>diachi</td>";
                    echo "<td>dienthoai</td>";
                    echo "<td>makhoa</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>";
                    $i = 0;
                    while($row = mysqli_fetch_assoc($result))
                    {
                        $mssv = $row["MSSV"];
                        $hoten= $row["HoTen"];
                        $ngaysinh = $row["NgaySinh"];
                        $diachi = $row["DiaChi"];
                        $dienthoai = $row["DienThoai"];
                        $makhoa = $row["MaKhoa"];
                        $i += 1;
                        echo "<form action='XemDanhSachHocSinh.php' method='GET'>";
                        echo "<tr>";
                        echo "<td>$i</td>";
                        echo "<td>$mssv</td>";
                        echo "<td>$hoten</td>";
                        echo "<td>$ngaysinh</td>";
                        echo "<td>$diachi</td>";
                        echo "<td>$dienthoai</td>";
                        echo "<td>$makhoa</td>";

                        echo "<td>";
                        echo "<a href='XemDanhSachSinhVien.php?MSSV=$mssv'> Xem chi tiết</a>";
                        echo "</td>";
                        echo "</tr>";

                    }
                    echo "</table>";
                    echo "</form>";
                } else {
                    echo "0 results";
                }
                mysqli_close($conn);
                ?>
            </div>
        </main>
    </div>
</div>


</body>
</html>
