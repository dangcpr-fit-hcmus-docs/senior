<?php
$title = "Thêm sinh viên";
$content = "Đây là trang thêm sinh viên";
require_once "layout.php";
