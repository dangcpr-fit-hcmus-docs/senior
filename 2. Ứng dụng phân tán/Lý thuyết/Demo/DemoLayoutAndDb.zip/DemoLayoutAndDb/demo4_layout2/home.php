<?php
$title = "Trang chủ";
$content = "Đây là trang chủ";
require_once "layout.php";
