<?php
$title = "Danh sách sinh viên";

$content = "<h1>Đây là trang danh sách sinh viên</h1>";

require_once "layout.php";
