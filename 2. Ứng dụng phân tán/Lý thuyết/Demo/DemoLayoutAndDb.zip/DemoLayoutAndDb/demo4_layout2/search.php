<?php
$title = "Tìm kiếm sinh viên";
$content = "Đây là trang tìm kiếm sinh viên";
require_once "layout.php";
