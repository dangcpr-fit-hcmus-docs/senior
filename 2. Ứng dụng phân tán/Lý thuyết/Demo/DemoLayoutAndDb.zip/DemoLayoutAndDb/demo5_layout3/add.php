<?php
$title = "Thêm sinh viên";
$content_path = "include/view_add.php";
require_once "layout.php";
