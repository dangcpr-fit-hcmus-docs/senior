<div>
    <form action="add.php" method="get">
        <div class="form-group">
            <label>MSSV</label>
            <input type="text" name="MSSV" class="form-control" placeholder="Hãy nhập MSSV ở đây">
        </div>
        <div class="form-group">
            <label>Họ và tên</label>
            <input type="text" name="HoTen" class="form-control" placeholder="Họ và tên">
        </div>
        <div class="form-group">
            <label>Ngày Sinh</label>
            <input type="text" name="NgaySinh" class="form-control" placeholder="Ngày Sinh">
        </div>

        <div class="form-group">
            <label>Địa chỉ</label>
            <input type="text" name="DiaChi" class="form-control" placeholder="Địa chỉ">
        </div>

        <div class="form-group">
            <label>Điện thoại</label>
            <input type="text" name="DienThoai" class="form-control" placeholder="Điện thoại">
        </div>
        <div class="form-group">
            <label>Mã khoa</label>
            <input type="text" name="MaKhoa" class="form-control" placeholder="Mã khoa">
        </div>
        <button type="submit" class="btn btn-primary">Thêm sinh viên mới</button>
    </form>
</div>