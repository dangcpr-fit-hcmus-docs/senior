<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "SinhVienDB";

if(isset($_REQUEST["btnTestConnection"]))
{
    $conn = @mysqli_connect($servername, $username, $password, $db);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");
    }
    echo "Connected successfully";
    mysqli_close($conn);
}

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if (!$conn) {
    die("Lỗi kết nối CSDL: " . mysqli_connect_error());
}

$sql = "SELECT * FROM SINHVIEN";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    echo "<form method='GET'>";

    echo "<table class='table'>";
    echo "<tr>";
    echo "<td>stt</td>";
    echo "<td>mssv</td>";
    echo "<td>hoten</td>";
    echo "<td>ngaysinh</td>";
    echo "<td>diachi</td>";
    echo "<td>dienthoai</td>";
    echo "<td>makhoa</td>";
    echo "<td>&nbsp;</td>";
    echo "<td>";
    $i = 0;
    while($row = mysqli_fetch_assoc($result))
    {
        $mssv = $row["MSSV"];
        $hoten= $row["HoTen"];
        $ngaysinh = $row["NgaySinh"];
        $diachi = $row["DiaChi"];
        $dienthoai = $row["DienThoai"];
        $makhoa = $row["MaKhoa"];
        $i += 1;
        echo "<form action='XemDanhSachHocSinh.php' method='GET'>";
        echo "<tr>";
        echo "<td>$i</td>";
        echo "<td>$mssv</td>";
        echo "<td>$hoten</td>";
        echo "<td>$ngaysinh</td>";
        echo "<td>$diachi</td>";
        echo "<td>$dienthoai</td>";
        echo "<td>$makhoa</td>";

        echo "<td>";
        echo "<a href='XemDanhSachSinhVien.php?MSSV=$mssv'> Xem chi tiết</a>";
        echo "</td>";
        echo "</tr>";

    }
    echo "</table>";
    echo "</form>";
} else {
    echo "0 results";
}
mysqli_close($conn);
?>