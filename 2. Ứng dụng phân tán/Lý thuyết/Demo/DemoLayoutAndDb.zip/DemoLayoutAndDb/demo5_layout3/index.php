<?php
$title = "Trang chủ";
$content_path = "include/view_home.php";
require_once "layout.php";
