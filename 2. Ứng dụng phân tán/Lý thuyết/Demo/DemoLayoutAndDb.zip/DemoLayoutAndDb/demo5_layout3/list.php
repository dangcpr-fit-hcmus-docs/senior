<?php
$title = "Danh sách sinh viên";
$content_path = "include/view_list.php";
require_once "layout.php";
