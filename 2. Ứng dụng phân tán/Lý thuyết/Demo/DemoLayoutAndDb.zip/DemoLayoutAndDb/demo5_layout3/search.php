<?php
$title = "Tìm kiếm sinh viên";
$content_path = "include/view_search.php";
require_once "layout.php";
