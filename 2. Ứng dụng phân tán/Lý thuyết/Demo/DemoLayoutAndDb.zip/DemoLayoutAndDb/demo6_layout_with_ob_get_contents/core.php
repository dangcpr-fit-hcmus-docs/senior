<?php
$title = "";
$layout = "";

define('DEFAULT_LAYOUT', 'layout.php');

function start_content($page_title = '', $page_layout = false)
{
    global $title;
    global $layout;
    $title = $page_title;
    $layout = $page_layout;
    $layout = $page_layout == false ? DEFAULT_LAYOUT : $page_layout;
    ob_start();
}

function end_content()
{
    global $title;
    global $layout;
    $content = ob_get_contents();
    ob_clean();
    ob_end_flush();
    require_once($layout);
}
?>