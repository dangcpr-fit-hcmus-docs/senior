<?php require("core.php"); ?>
<?php start_content("Page 1"); ?>
This is content of page 1
<?php end_content(); ?>
