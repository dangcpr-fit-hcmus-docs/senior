<?php require("core.php"); ?>
<?php start_content("Page 2"); ?>
This is content of page 2
<?php end_content(); ?>
