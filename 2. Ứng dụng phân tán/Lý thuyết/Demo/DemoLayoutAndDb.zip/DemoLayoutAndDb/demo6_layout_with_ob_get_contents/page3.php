<?php require("core.php"); ?>
<?php start_content("Page 3"); ?>

This is the content of Page 3

<?php end_content(); ?>
