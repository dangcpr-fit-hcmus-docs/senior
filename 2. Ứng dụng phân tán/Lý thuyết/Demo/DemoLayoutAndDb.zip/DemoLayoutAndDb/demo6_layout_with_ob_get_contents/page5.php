<?php require("core.php"); ?>
<?php start_content("Page 5"); ?>

This is the content of Page 5

<?php end_content(); ?>
