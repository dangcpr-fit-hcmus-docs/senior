<?php
ob_start();
echo "Hieu.dev. ";
echo "From e-web.vn";
$content1 = ob_get_contents();
ob_clean();
ob_end_flush();
//echo $content1; // Hieu.dev. From e-web.vn

ob_start();
echo "The quick brown fox Jumps over the lazy dog.";
$content2 = ob_get_contents();
ob_clean();
ob_end_flush();

echo "HEADER=". $content1;
echo "CONTENT=". $content2; // The quick brown fox Jumps over the lazy dog.
?>