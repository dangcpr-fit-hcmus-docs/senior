<?php

require_once("./controller/SinhVien.php");
require_once("./model/SinhVien.php");

$controller = new SinhVienController();

$controller->layDanhSach();
?>
