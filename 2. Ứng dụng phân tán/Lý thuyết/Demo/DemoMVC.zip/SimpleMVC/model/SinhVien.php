<?php

class SinhVienModel
{
    static public function layDanhSach()
    {
        $data = array("A", "B", "C", "D", "E");
        return $data;        
    }
}
?>
