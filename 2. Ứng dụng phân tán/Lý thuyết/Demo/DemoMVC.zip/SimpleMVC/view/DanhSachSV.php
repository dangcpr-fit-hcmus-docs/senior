<hr/>
<?php
echo $x . "<br/>";
foreach ($data as $item)
{
    echo $item . "<br/>";
}
?>
