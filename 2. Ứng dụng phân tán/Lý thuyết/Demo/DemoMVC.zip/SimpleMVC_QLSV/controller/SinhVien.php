<?php

class SinhVienController
{
    public function listAll()
    {
        $data = SinhVienModel::listAll();        
        require("./view/DanhSachSV.php");
    }
    
    public function search($keyword)
    {
        $data = SinhVienModel::find($keyword);
        require("./view/DanhSachSV.php");
    }
}
?>
