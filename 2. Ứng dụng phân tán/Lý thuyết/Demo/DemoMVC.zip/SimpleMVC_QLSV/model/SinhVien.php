<?php

class SinhVienModel
{

    public $MSSV;
    public $HOTEN;
    
    function __construct() {
        $this->MSSV = "";
        $this->MSSV = "";
    }
    
    public static function listAll() {
        require_once("config/dbconnect.php");
        
        $mysqli->query("SET NAMES utf8");
        $query = "SELECT * FROM SINHVIEN";
        $result = $mysqli->query($query);
        $dssv = array();
        if ($result) 
        {            
            foreach ($result as $row) {
                $sv = new SinhVienModel();
                $sv->HOTEN = $row["HoTen"];
                $sv->MSSV = $row["MSSV"];     
                $dssv[] = $sv; //add an item into array
            }
        }
        $mysqli->close();
        return $dssv;
    }
    public static function find($keyword) {
        require_once("config/dbconnect.php");
        
        $mysqli->query("SET NAMES utf8");
        $query = "SELECT * FROM SINHVIEN WHERE HoTen LIKE '%$keyword%'";
        $result = $mysqli->query($query);
        $dssv = array();
        if ($result) 
        {            
            foreach ($result as $row) {
                $sv = new SinhVienModel();
                $sv->HOTEN = $row["HoTen"];
                $sv->MSSV = $row["MSSV"];     
                $dssv[] = $sv; //add an item into array
            }
        }
        $mysqli->close();
        return $dssv;
    }
}
?>
