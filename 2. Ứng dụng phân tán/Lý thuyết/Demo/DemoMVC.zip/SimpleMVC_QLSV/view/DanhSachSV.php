<h1>DANH SÁCH SINH VIÊN</h1>
<hr/>

<form action="Index.php" method="get">
    <input type="text" name="keyword"/>
    <input type="submit" value="search"/>
    <input type="hidden" name="action" value="search"/>
</form>

<?php
$i = 1;
foreach ($data as $item) 
{    
    echo $i . ":" . $item->MSSV . " " . $item->HOTEN . "<br/>";
    $i = $i + 1;
}

?>

