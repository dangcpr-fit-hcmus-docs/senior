<?php
	error_reporting(E_ERROR | E_PARSE);
	require("db.inc");
	
	if (isset($_POST['MANV']))
	{
		$manv = $_POST['MANV'];
		$mysqli = connect();
	    $mysqli->query("SET NAMES utf8");
	    $query = "SELECT * FROM NhanVien Where MANV LIKE '$manv'";
	    $result = $mysqli->query($query);     
		header('Content-type: application/json');

		if  ($row = $result->fetch_object() ) {
	        echo json_encode($row);	
		}
		else
			echo json_encode(null);

		$mysqli->close();		
	}
	else
	{
		echo json_encode(array("error"=>"Thiếu tham số MANV trong request"));	
	}
	
?>