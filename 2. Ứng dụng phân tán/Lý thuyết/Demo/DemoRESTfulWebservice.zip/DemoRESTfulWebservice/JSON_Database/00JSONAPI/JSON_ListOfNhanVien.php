<?php
	error_reporting(E_ERROR | E_PARSE);
	require("db.inc");	
	$query = "SELECT MANV, HoTen FROM NhanVien ORDER BY MANV";	
	$mysqli = connect();
	$mysqli->query("SET NAMES utf8");	
	$result = $mysqli->query($query);
	
    $arr = array();
    if ($result) 
    {            
        foreach ($result as $row) {
            
            $arr[] = $row; //add an item into array
        }
    }
    $mysqli->close();
	
	header('Content-type: application/json');
	echo json_encode($arr);	
?>