﻿<?php
	error_reporting(E_ERROR | E_PARSE);
	if (isset($_REQUEST['q']))
	{
		require("db.inc");

		$q = $_REQUEST['q'];				
		$query = "SELECT * FROM NhanVien Where HoTen LIKE '%$q%'";
		
		$mysqli = connect();
		$mysqli->query("SET NAMES utf8");	
		$result = $mysqli->query($query);
		
	    $arr = array();
	    if ($result) 
	    {            
	        foreach ($result as $row) {
	            
	            $arr[] = $row; //add an item into array
	        }
	    }
	    $mysqli->close();
		header('Content-type: application/json');
		echo json_encode($arr);	
	}
	else
	{
		echo json_encode(array("error"=>"Thiếu tham số q trong request"));	
	}
?>