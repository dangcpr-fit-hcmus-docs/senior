﻿-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2011 at 07:40 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `NhanVienDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE IF NOT EXISTS `nhanvien` (
  `MaNV` varchar(50) DEFAULT NULL,
  `HoTen` varchar(255) DEFAULT NULL,
  `NgaySinh` varchar(50) DEFAULT NULL,
  `DiaChi` varchar(255) DEFAULT NULL,
  `Phai` varchar(50) DEFAULT NULL,
  `Luong` varchar(50) DEFAULT NULL,
  `Phong` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `nhanvien` (`MaNV`, `HoTen`, `NgaySinh`, `DiaChi`, `Phai`, `Luong`, `Phong`) VALUES
('601', 'Lacota R. Wolf', '1981-10-22 05:09:10', 'Ap #458-1788 Sit St.', '1', '833', '3'),
('509', 'Abbot R. Sanford', '1985-06-20 14:20:14', '930-1342 Arcu Street', '1', '325', '2'),
('500', 'Michelle M. Gaines', '1990-06-17 02:15:08', '6791 Consequat Rd.', '0', '786', '2'),
('560', 'Willa X. Walton', '1986-03-22 13:39:00', '6391 Sit Ave', '0', '779', '2'),
('905', 'Kamal I. Petersen', '1983-11-19 18:37:39', 'P.O. Box 528, 2578 Varius Av.', '1', '389', '3'),
('200', 'Dillon Y. Best', '1980-04-05 21:21:14', 'Ap #366-6481 Leo. St.', '1', '442', '3'),
('843', 'Adrian L. Gonzalez', '1988-01-29 09:29:02', '1461 Sem, St.', '1', '680', '2'),
('183', 'Jessamine O. Mullen', '1992-06-15 00:36:20', 'Ap #371-4029 Posuere Street', '1', '523', '2'),
('934', 'Justina F. Blevins', '1984-12-23 21:55:19', '732-6097 Elementum Av.', '0', '332', '1'),
('744', 'Ciaran W. Wilson', '1982-01-15 08:39:23', '955-1020 Egestas Rd.', '1', '611', '4'),
('332', 'Dalton R. Butler', '1986-05-21 13:51:39', '1528 Lacus. Rd.', '0', '340', '2'),
('237', 'Shaine W. Scott', '1991-11-03 15:51:08', '5249 Augue Street', '0', '365', '2'),
('882', 'Xavier E. Buchanan', '1986-07-15 09:00:52', 'P.O. Box 493, 381 Ut St.', '0', '702', '1'),
('164', 'Tallulah B. Mueller', '1984-12-29 03:42:15', 'P.O. Box 458, 8086 Tincidunt Rd.', '1', '436', '3'),
('483', 'Keefe Y. Mathis', '1985-07-27 22:19:04', '471-6526 Rutrum, Ave', '1', '660', '3'),
('785', 'Porter U. Aguilar', '1981-11-13 09:49:38', '2523 Odio. Ave', '1', '658', '2'),
('635', 'Deanna Z. Hogan', '1980-10-03 07:24:45', 'P.O. Box 747, 8303 Orci. Road', '1', '474', '4'),
('363', 'Xena S. Daniel', '1989-11-16 05:04:27', '269-5423 Erat, Ave', '0', '416', '2'),
('314', 'Stacy M. Espinoza', '1985-07-04 04:20:27', '370 Risus Av.', '0', '429', '1'),
('259', 'MacKenzie X. Dillard', '1986-10-10 19:05:53', 'P.O. Box 298, 2877 Luctus Avenue', '0', '565', '4'),
('799', 'Colton Z. Fitzgerald', '1985-08-15 09:31:02', 'P.O. Box 174, 5941 Ipsum. Road', '0', '512', '1'),
('516', 'Cooper M. Snyder', '1992-04-28 19:53:39', 'Ap #564-6924 Consectetuer St.', '1', '547', '1'),
('765', 'Lila A. Graham', '1991-08-29 20:27:46', 'P.O. Box 579, 247 Ipsum. Av.', '0', '599', '4'),
('684', 'Mechelle G. Small', '1988-07-30 20:07:33', '233-4345 Commodo St.', '0', '683', '4'),
('316', 'Calista Y. Figueroa', '1989-03-23 01:22:08', 'P.O. Box 674, 3029 Curabitur Ave', '0', '695', '1'),
('296', 'Melodie G. Mcconnell', '1991-03-29 10:17:04', 'P.O. Box 647, 7432 Elit, St.', '1', '808', '2'),
('157', 'Candace M. Mayo', '1987-07-15 20:58:32', '607-3687 Sociis St.', '1', '596', '2'),
('320', 'Kristen O. Thornton', '1983-01-23 21:55:51', 'Ap #275-2291 Morbi Rd.', '0', '557', '1'),
('333', 'Ina Z. Rojas', '1990-10-16 22:04:15', '415-7948 Molestie Rd.', '0', '806', '1'),
('297', 'Beverly P. Odonnell', '1983-10-07 20:50:20', '8950 Mus. St.', '1', '745', '2'),
('739', 'Emi X. Avila', '1991-01-10 19:32:40', '730-4651 Magnis St.', '1', '593', '2'),
('147', 'Brianna K. Sutton', '1989-09-21 01:06:00', 'P.O. Box 131, 1168 Nunc Avenue', '0', '730', '3'),
('998', 'Tanisha X. Leon', '1986-08-01 12:27:35', '402-5726 Elit Street', '0', '445', '1'),
('597', 'Larissa A. Rogers', '1985-02-10 09:49:13', '453-4074 Rhoncus. Street', '0', '777', '2'),
('323', 'Alvin J. Goodwin', '1986-11-20 19:43:44', 'P.O. Box 446, 9636 Porttitor St.', '1', '466', '3'),
('859', 'Linus K. Vega', '1984-06-23 22:04:57', '556-7445 Eu, St.', '0', '612', '1'),
('608', 'Zena Z. Jensen', '1988-09-02 09:09:00', '635-3154 Ultricies Street', '1', '870', '3'),
('739', 'Zeph R. Bolton', '1984-02-11 07:25:22', '469-9612 Arcu. Road', '0', '794', '4'),
('417', 'Fitzgerald C. Hill', '1992-04-15 20:54:17', 'P.O. Box 256, 9331 Proin Avenue', '1', '384', '2'),
('929', 'Iliana F. Stevenson', '1983-03-15 16:22:56', '7755 Tristique Av.', '1', '303', '2'),
('447', 'Gray U. Patrick', '1983-05-31 14:33:07', 'Ap #315-2531 Cum Avenue', '1', '698', '2'),
('595', 'Lisandra S. Lancaster', '1987-03-11 01:09:13', '8191 Ligula. St.', '0', '473', '3'),
('387', 'Germane G. Lang', '1981-03-30 10:08:40', 'P.O. Box 614, 7261 Sit Road', '1', '468', '3'),
('944', 'Cathleen E. Campbell', '1989-03-14 20:22:29', '7608 Dolor St.', '1', '567', '2'),
('417', 'Yoshio F. Hopkins', '1982-10-04 13:57:06', 'Ap #542-8504 Fringilla Rd.', '1', '306', '1'),
('983', 'Geoffrey O. Gilmore', '1982-05-04 07:46:24', '5946 Magna Avenue', '1', '304', '3'),
('166', 'Illiana X. Ryan', '1986-12-06 15:17:02', '512-7892 Ut, Road', '0', '841', '1'),
('224', 'Ina Q. Knapp', '1987-12-31 19:47:36', 'Ap #435-3522 Arcu. Road', '1', '729', '4'),
('153', 'Michael Q. Pope', '1981-12-26 23:31:06', '674-1735 Tempor Ave', '0', '631', '2'),
('656', 'Timon K. Salazar', '1984-09-04 06:03:25', '446-1481 Lorem Ave', '1', '308', '2'),
('352', 'Matthew Q. Romero', '1980-11-02 07:40:52', 'Ap #727-1871 Quis, Rd.', '0', '507', '3'),
('996', 'Odysseus E. Hansen', '1991-06-20 06:07:11', 'Ap #572-8451 Consectetuer Avenue', '0', '859', '1'),
('126', 'Galvin E. Jensen', '1991-06-03 06:09:11', 'Ap #581-1511 Sed Rd.', '0', '396', '4'),
('898', 'Murphy B. Johnston', '1989-08-17 01:07:01', '9400 Non Av.', '1', '416', '1'),
('509', 'Brittany Z. Medina', '1985-12-24 09:25:37', '730 Odio, Avenue', '1', '449', '3'),
('217', 'Juliet S. Baird', '1980-11-04 11:03:46', 'P.O. Box 278, 9545 Dolor St.', '1', '831', '2'),
('145', 'Sage W. Duran', '1991-02-24 15:52:26', 'P.O. Box 880, 2704 Metus Av.', '0', '588', '1'),
('241', 'Howard F. Carver', '1985-08-14 02:36:38', '5091 Molestie Road', '1', '774', '1'),
('948', 'Winter D. Fuller', '1984-11-30 06:52:02', 'P.O. Box 413, 3576 Ornare Street', '1', '665', '1'),
('656', 'Hyatt M. Ellis', '1980-05-28 16:29:49', '9229 Dis Rd.', '1', '527', '1'),
('841', 'Philip P. Jensen', '1991-01-21 22:45:00', '530-3294 Diam Road', '0', '779', '2'),
('323', 'Benjamin P. Kaufman', '1991-07-28 02:04:03', 'P.O. Box 695, 9589 Cras Road', '1', '856', '2'),
('371', 'Hall F. Henry', '1986-06-14 22:21:53', '823-5454 Imperdiet Av.', '1', '532', '4'),
('239', 'Prescott M. Ewing', '1982-06-10 00:08:03', '3473 Quisque St.', '0', '557', '4'),
('660', 'Quinn H. Cardenas', '1987-11-07 11:37:35', 'P.O. Box 254, 739 Orci Ave', '1', '649', '2'),
('608', 'Guy J. Mccormick', '1989-07-19 23:19:42', '7111 Massa. Road', '1', '609', '4'),
('989', 'Lucas Y. Bell', '1980-05-09 12:08:38', '897-8550 Lobortis Street', '0', '317', '1'),
('870', 'Reed A. Golden', '1982-02-12 19:41:02', 'Ap #230-5022 Neque Avenue', '1', '738', '4'),
('900', 'Barclay P. Merrill', '1980-08-06 03:22:22', 'Ap #630-7467 Magna St.', '1', '611', '3'),
('884', 'Stone S. Mccall', '1984-09-03 20:00:20', '8608 Elit. Rd.', '0', '426', '4'),
('332', 'Caesar K. Kerr', '1983-08-29 08:02:45', 'P.O. Box 554, 3708 Pede. Rd.', '0', '375', '4'),
('838', 'Desiree K. Lott', '1981-06-20 11:31:28', '7027 Aliquam St.', '0', '783', '2'),
('803', 'Roanna Q. Sutton', '1984-03-18 00:09:53', '5595 Vestibulum Street', '1', '898', '1'),
('950', 'Mara B. Leblanc', '1988-08-15 04:36:12', '341-8548 Nec, Avenue', '0', '619', '2'),
('574', 'Kennan L. Mccarty', '1991-11-06 17:48:12', '564-4243 Diam Rd.', '0', '542', '1'),
('762', 'Naida H. Valentine', '1981-07-07 12:59:00', '260-5528 Phasellus Avenue', '1', '453', '3'),
('785', 'Kimberly P. Wells', '1982-01-25 00:31:54', 'P.O. Box 275, 365 Vestibulum Rd.', '1', '690', '2'),
('308', 'Timon Q. Robertson', '1984-06-15 20:54:01', 'Ap #741-8736 Leo. St.', '1', '302', '1'),
('585', 'Genevieve C. Ferrell', '1984-06-29 15:43:11', '9776 Eget Rd.', '0', '742', '3'),
('781', 'Cruz Y. Mcknight', '1991-05-10 07:34:28', 'Ap #564-4340 Placerat, St.', '1', '478', '1'),
('540', 'Jescie F. Rollins', '1986-05-01 12:37:17', 'P.O. Box 511, 9568 Ac Road', '1', '745', '1'),
('791', 'Dustin T. Sawyer', '1987-10-14 14:24:35', '213-7851 Eleifend Rd.', '1', '346', '1'),
('225', 'Mollie O. Lyons', '1980-02-01 11:13:02', 'Ap #711-3339 Tempor Av.', '0', '829', '3'),
('866', 'Baker V. Cameron', '1986-09-25 10:13:08', '4134 Quis, Av.', '0', '705', '1'),
('573', 'Dakota Q. Keller', '1986-04-15 14:22:17', 'Ap #144-5755 Quisque Road', '0', '661', '1'),
('639', 'Ivor H. Rocha', '1989-01-01 01:39:22', 'P.O. Box 509, 795 Ligula St.', '0', '655', '4'),
('897', 'Jasper H. Pollard', '1985-07-16 21:24:08', '235-6402 Pede, Road', '1', '781', '3'),
('433', 'Keely Y. Park', '1990-04-23 08:34:01', 'P.O. Box 584, 7531 Cras Street', '1', '790', '3'),
('175', 'Yen D. Witt', '1986-02-24 14:03:39', 'P.O. Box 198, 518 Fermentum Rd.', '1', '542', '3'),
('250', 'Shay U. Sargent', '1991-07-11 12:58:39', '242-1593 Et Rd.', '0', '360', '1'),
('513', 'Chandler F. Miller', '1982-04-16 19:32:41', 'Ap #214-4260 Nunc Road', '1', '467', '3'),
('361', 'Evelyn I. Ray', '1982-12-05 02:33:21', 'P.O. Box 315, 171 Neque. St.', '1', '325', '4'),
('496', 'Joshua P. Webster', '1982-11-18 03:58:57', 'Ap #200-2427 Tristique St.', '0', '492', '2'),
('775', 'Anjolie E. Henderson', '1988-03-18 08:13:23', '721 Luctus Ave', '1', '641', '2'),
('162', 'Olga H. Hartman', '1989-03-14 23:51:26', '575-6576 Curae; St.', '1', '589', '1'),
('550', 'Kendall P. Vega', '1985-11-17 11:42:09', '609 Ligula. Street', '1', '894', '2'),
('239', 'Price Z. Carey', '1985-03-18 09:44:54', 'Ap #297-2160 Felis St.', '0', '669', '3'),
('994', 'Samson N. Spencer', '1990-03-28 09:39:44', 'P.O. Box 755, 2209 Molestie Ave', '1', '692', '4'),
('382', 'Sylvia J. Reeves', '1984-11-12 16:38:19', '300 Proin Ave', '1', '880', '4'),
('399', 'Bianca O. Le', '1991-07-10 06:53:58', 'P.O. Box 846, 7834 Enim, Av.', '1', '717', '2');
