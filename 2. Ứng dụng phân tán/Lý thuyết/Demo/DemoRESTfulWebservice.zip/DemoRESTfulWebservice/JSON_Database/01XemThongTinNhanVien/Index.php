<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript" language="javascript">
	var xmlHttp;
	function CreateXMLHttpRequest()
	{
		if ( window.XMLHttpRequest )
		{
			 // code for IE7+, Firefox, Chrome, Opera, Safari
			return new XMLHttpRequest()
		}
		else if (window.ActiveXObject )
		{
			 // code for IE6, IE5
			return new ActiveXObject("Microsoft.XMLHTTP")
		}
	}
	
	
	function onDSNVchange(manv)
	{
		xmlHttp = CreateXMLHttpRequest();
		
		xmlHttp.onreadystatechange = showResult;
		var host = "http://localhost:8899/DemoRESTfulWebservice/JSON_Database/00JSONAPI"
		var serverURL = host + '/JSON_GetNhanVien.php?MANV=' + encodeURI(manv) + "&t=" + (new Date()).getTime();
				
		xmlHttp.open("get", serverURL, true);
		
		xmlHttp.send(null);
		
	}
	
	function showResult()
	{
		if(xmlHttp.readyState == 4 && xmlHttp.status == 200)
		{
			var kq = xmlHttp.responseText;
			
			var jSONObject = eval("(" + kq + ")");
		
			document.getElementById("MaNV").innerHTML = jSONObject.MaNV;
			document.getElementById("HoTen").innerHTML = jSONObject.HoTen;
			document.getElementById("NgaySinh").innerHTML = jSONObject.NgaySinh;
			document.getElementById("DiaChi").innerHTML = jSONObject.DiaChi;
			document.getElementById("Phai").innerHTML = jSONObject.Phai;
			document.getElementById("Luong").innerHTML = jSONObject.Luong;
			document.getElementById("Phong").innerHTML = jSONObject.Phong;					
		}
	}
</script>
</head>

<body>

<?php
	$ch = curl_init();
	$host = "http://localhost:8899/DemoRESTfulWebservice/JSON_Database/00JSONAPI";
	curl_setopt($ch, CURLOPT_URL, $host . "/JSON_ListOfNhanVien.php");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$s = curl_exec ($ch);
	curl_close ($ch);
	
	$json_a=json_decode($s, true);
		
	$data = "";
	foreach($json_a as $p)
	{
		$manv = $p["MANV"];
		$hoten = $p["HoTen"];
		$data = $data."<option value='$manv'> $manv - $hoten</option>";
	}
	
	echo "<select name='controlDSNV' onchange ='onDSNVchange(this.value);'>$data</select>";
	

?>
	<div id="divResult">
    	MaNV: <span id="MaNV"></span> <br/>
        HoTen: <span id="HoTen"></span> <br/>
        NgaySinh: <span id="NgaySinh"></span> <br/>
        DiaChi: <span id="DiaChi"></span> <br/>
        Phai: <span id="Phai"></span> <br/>
        Luong: <span id="Luong"></span> <br/>
        Phong: <span id="Phong"></span> <br/>
        
    </div>
</body>
</html>

