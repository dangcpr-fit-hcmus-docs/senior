<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>

<?php
	error_reporting(E_ERROR | E_PARSE);
	$manv = "153";
	$fields_string = "MANV=$manv";
	
	$ch = curl_init();
	$host = "http://localhost:8899/DemoRESTfulWebservice/JSON_Database/00JSONAPI";
	curl_setopt($ch, CURLOPT_URL, $host . "/JSON_GetNhanVien_POST.php");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch,CURLOPT_POST,1); //Number of parameters
	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);	
	$s = curl_exec ($ch);	
	curl_close ($ch);	
	// header("application/json");
	// echo $s;
	$data = json_decode($s, true);
	print_r($data);
?>	
</body>
</html>

