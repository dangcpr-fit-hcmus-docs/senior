<h1>JSON & PHP: json_decode(), json_encode() </h1>
<?php
	echo "<h3> Example 1 </h3>";
	
  	$string='{"name":"John Adams"}';
	
	$json_a=json_decode($string,true);
		   
	echo $json_a["name"];
	
	echo "<h3> Example 2 </h3>";
	
	$string='{"name":{"first":"John","last":"Adams"},"age":"40"}';
	
	$json_a = json_decode($string,true);

	echo  $json_a["name"]["first"];
	
	echo  $json_a["name"]["last"];
	
	echo "<h3> Example 3 </h3>";
	
	$string='[
			  {"name":{"first":"John","last":"Adams"},"age":"40"},
			  {"name":{"first":"Thomas","last":"Jefferson"},"age":"35"}
             ]';
	$json_a=json_decode($string,true);

	echo $json_a[1]["age"];
	
	echo "<h3> Example 4 </h3>";
	
	$string='{"person":[
			{
				"name":{"first":"John","last":"Adams"},
                "age":"40"
			},
			{
				"name":{"first":"Thomas","last":"Jefferson"},
                "age":"35"
			}
		 ]}';

	$json_a=json_decode($string,true);

	$json_o=json_decode($string);
	// array method
	foreach($json_a["person"] as $p)
	{
		echo 'Name: '.$p["name"]["first"].' '.$p["name"]["last"].'Age: '.$p["age"].''."<br/>";

	}
	
	// object method
	foreach($json_o->person as $p)
	{
		echo 'Name: '.$p->name->first.' '.$p->name->last.'Age: '.$p->age.''."<br/>";;
	}
?>