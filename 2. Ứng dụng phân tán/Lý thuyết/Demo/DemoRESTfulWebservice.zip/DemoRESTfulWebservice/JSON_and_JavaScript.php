<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>
<body>
<h1>Encode & Decode JSON with Javascript </h1>
<hr />
<h3>JSON - Declare and retrive </h3>
<script type="text/javascript">
	
	var employees = [
					{ "firstName":"John" , "lastName":"Doe" }, 
					{ "firstName":"Anna" , "lastName":"Smith" }, 
					{ "firstName":"Peter" , "lastName": "Jones" }
					];
	
	document.writeln(employees[0]["firstName"]);
	document.writeln(employees[0].firstName);
</script>
<hr/>

<h3>JSON - Read a object and create JSON Object from a string </h3>
<script type="text/javascript">
	var name = 	{ "firstName":"John" , "lastName":"Doe" };
	document.writeln(name.firstName);
	
	var text = '{ "firstName":"John" , "lastName":"Doe" }';
	var json = eval ("(" + text + ")");

	document.writeln(json.firstName);
</script>
<hr/>
<h3>JSON - Read a object in an array </h3>
<script type="text/javascript">	

var jsonObject2 = [
			{"name":{"first":"John","last":"Adams"},"age":"40"},
			{"name":{"first":"Thomas","last":"Jefferson"},"age":"35"}
			];

document.writeln(jsonObject2[0].name.last);
</script>
<hr/>
<h3>JSON - Read a object in an array </h3>
<script type="text/javascript">
var jsonObject3 = {"person":[
			{
				"name":{"first":"John","last":"Adams"},
				"age":"40"
			},
			{
				"name":{"first":"Thomas","last":"Jefferson"},
				"age":"35"
			}
			]};

document.writeln(jsonObject3.person[0].name.first);
</script>
<hr/>
<h3>Convert a JSON object to STRING </h3>
<script type="text/javascript">

var jsonObject4 = {"person":[
			{
				"name":{"first":"John","last":"Adams"},
				"age":"40"
			},
			{
				"name":{"first":"Thomas","last":"Jefferson"},
				"age":"35"
			}
			]};
var JSONstring = JSON.stringify(jsonObject4);

document.writeln(JSONstring);
</script>
</body>
</html>
