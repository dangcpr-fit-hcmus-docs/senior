﻿<?php
header('Content-type: application/json');
// 1. Ket noi CSDL
$connection = mysql_connect("localhost","root","");
mysql_select_db("NhanVienDB", $connection);
// 2. Chuan bi cau truy van & 3. Thuc thi cau truy van
$strSQL = "SELECT * FROM NhanVien";
$result = mysql_query($strSQL);
$n = mysql_num_rows($result);
$arr = array();
// 4.Xu ly du lieu tra ve
while ($row = mysql_fetch_object($result))
{
	$arr[] = $row;	
}
echo json_encode($arr);	
// 5. Dong ket noi
mysql_close($connection);

?>
