<?php
 /**
 * Initialize the cURL session
 */
 $ch = curl_init();

 /**
 * Set the URL of the page or file to download.
 */
 curl_setopt($ch, CURLOPT_URL, "http://news.google.com/news?hl=en&topic=t&%20output=rss");

 /**
 * Ask cURL to return the contents in a variable instead of simply echoing them to  the browser.
 */
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 
 curl_setopt($ch, CURLOPT_PROXY, "172.29.2.12"); 
 
 curl_setopt($ch, CURLOPT_PROXYPORT, "8080");  

 /**
 * Execute the cURL session
 */
 $contents = curl_exec ($ch);

 /**
 * Close cURL session
 */
 curl_close ($ch);
 
 
 echo $contents;

?>