<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
</head>

<body>
	<script type="text/javascript">
		$(document).ready(function(){
			var settings = {
			  "async": true,
			  "crossDomain": true,
			  "url": "headttp://dataservice.accuweather.com/forecasts/v1/daily/1day/353981?apikey=fC3sxp2g67Saek6Be3eb9Apc1k23XkfA&language=vi-vn",
			  "method": "GET",
			  "headers": {
			    "Content-Type": "application/json",
			    "cache-control": "no-cache",
			    "Postman-Token": "8c4b211d-1000-4f87-b32e-5e90eb1d1c36"
			  },
			  "processData": false,
			  "data": ""
			}

			$.ajax(settings).done(function (response) {
			  	console.log(response);
			});
		});
	</script>
	<form method="post">
		<input type="submit" name="btnSubmit" value="Xem thông tin thời tiết" >
	</form>
	
</body>
</html>
<?php

if (isset($_REQUEST["btnSubmit"]))
{
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://dataservice.accuweather.com/forecasts/v1/daily/1day/353981?apikey=fC3sxp2g67Saek6Be3eb9Apc1k23XkfA&language=vi-vn",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "GET",
	  CURLOPT_POSTFIELDS => "",
	  CURLOPT_HTTPHEADER => array(
	    "Content-Type: application/json",
	    "Postman-Token: 7b4329db-0902-43ee-82c7-fee5a07474f4"
	    // "cache-control: no-cache"
	  ),
	));

	$response = curl_exec($curl);
	$data = json_decode($response, true);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
	  	echo "cURL Error #:" . $err;
	} else {
		// print_r($data["Headline"]);
		$message = $data["Headline"]["Text"];
		$href = $data["Headline"]["Link"];
	  	echo "<h1>$message</h1>";
	  	echo "<a href='$href'>$href</a>";
	}
}


