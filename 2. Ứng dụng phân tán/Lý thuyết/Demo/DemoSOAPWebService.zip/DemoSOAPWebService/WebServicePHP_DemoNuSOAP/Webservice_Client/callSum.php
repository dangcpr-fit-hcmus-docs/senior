﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Client</title>
</head>

<body>
<h1>Webservice Client - call SUM service</h1>
<form  method="post">
Số thứ nhất:
<input type="text" name="So1" value="<?php if (isset($_POST['So1'])) echo $_POST['So1'];?>"/><br />
Số thứ hai:
<input type="text" name="So2" value="<?php if (isset($_POST['So2'])) echo $_POST['So2'];?>"/><br />
<input type="submit" value="call SUM"/><br />
<hr/>

<?php
if (isset($_POST["So1"]) && isset($_POST["So2"]))
{				 
	error_reporting(E_ERROR | E_PARSE);
	require_once("nuSOAP/lib/nusoap.php");

	//Tạo đối tượng để thực hiện gọi Web service
	$client = new nusoap_client('http://localhost:8899/DemoSOAPWebService/WebServicePHP_DemoNuSOAP/Webservice_Server/index.php?wsdl', true);
	
	// Gọi phương thức Sum
	$ketqua = $client->call('Sum', array('x1' => $_POST["So1"],'x2' => $_POST["So2"]));

	// Hiển thị kết quả
	echo "Kết quả  : <b style='color:red;font-size:25px'>".$ketqua."</b>";
}
?>
</form>
</body>
</html>