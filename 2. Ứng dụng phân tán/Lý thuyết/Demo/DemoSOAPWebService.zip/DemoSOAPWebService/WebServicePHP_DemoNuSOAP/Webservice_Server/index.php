<?php
// 1. inport file nusoap.php
error_reporting(E_ERROR | E_PARSE);
require_once("nuSOAP/lib/nusoap.php");

// Tạo đối tượng soap server
$server = new soap_server();

// Cấu hình WSDL
$server->configureWSDL("WebserviceDemo");

// Thiết lập namespace
$namespace = "http://localhost:8080/Webservice_Server/index.php";
$server->wsdl->schemaTargetNamespace = $namespace;

//Đăng ký các phuwogn thức cho webservice
$server->register('Hello', array("name"=>"xsd:string"),array("result"=>"xsd:string"),$namespace);
$server->register('Sum', array("x1"=>"xsd:integer","x2"=>"xsd:integer"),array("ketqua"=>"xsd:integer"),$namespace);

//Khai báo và cài đặt các hàm Webservice
function Hello($name) {
    return "Hello: <b>" . $name . "</b>";
}

function Sum($x1, $x2) {
    return $x1 + $x2;
}

$POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA']) 
                ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';

@$server->service(file_get_contents("php://input"));
// $server->service($POST_DATA);
// $server->service($POST_DATA);
exit();
?>