﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Client</title>
</head>

<body>

<form  method="post">
Name :
<input type="text" name="Keyword" value="<?php if (isset($_POST['Keyword'])) echo $_POST['Keyword'];?>"/>

<input type="submit" value="call Hello"/><br />
<hr/>

<?php
if (isset($_POST["Keyword"]) )
{			
	echo $_POST["Keyword"];
	error_reporting(E_ERROR | E_PARSE);	 
	require_once("nuSOAP/lib/nusoap.php");

	//Tạo đối tượng để thực hiện gọi Web service
	$client = new nusoap_client('http://localhost:8899/DemoSOAPWebService/WebServicePHP_DemoNuSOAPDB/Webservice_Server/index.php?wsdl', true);
	
	// Gọi phương thức Hello
	$ketqua = $client->call('Search', array('keyword' => $_POST["Keyword"]));
	print_r($ketqua);
}

?>
</form>
</body>
</html>