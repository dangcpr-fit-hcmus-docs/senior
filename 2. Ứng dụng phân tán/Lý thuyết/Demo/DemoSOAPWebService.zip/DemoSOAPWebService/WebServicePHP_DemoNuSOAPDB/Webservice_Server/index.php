<?php
// 1. inport file nusoap.php
error_reporting(E_ERROR | E_PARSE);
require_once("nuSOAP/lib/nusoap.php");
require_once("db.inc");

$server = new soap_server();

// Cấu hình WSDL
$server->configureWSDL("WebserviceDemo");
// Thiết lập namespace
$namespace = "http://localhost/Webservice_Server/index.php";
$server->wsdl->schemaTargetNamespace = $namespace;

//Đăng ký các phuwogn thức cho webservice
$server->register('Search', array("keyword"=>"xsd:string"),array("result"=>"xsd:string"),$namespace);

//Khai báo và cài đặt các hàm Webservice
function Search($keyword) {
    
	//return "ABC".$name;
	// 1. Ket noi CSDL

	$mysqli = connect();
    $mysqli->query("SET NAMES utf8");
    $query = "SELECT * FROM NhanVien WHERE HoTen LIKE '%$keyword%'";
    $result = $mysqli->query($query);     
	




	// 4.Xu ly du lieu tra ve
	$data = "";
	$data = $data."<tr>
					<th>MANV</th>
					<th>Họ tên</th>
					<th>Ngày sinh</th>
					<th>Địa chỉ</th>
					<th>Điện thoại</th>
					<th>Mã khoa</th>
				   </tr>";
	if ($result) 
    {            
        foreach ($result as $row) {
            
            $manv = $row["MaNV"];
			$hoten = $row["HoTen"];
			$ngaysinh = $row["NgaySinh"];
			$diachi = $row["DiaChi"];
			$phai = $row["Phai"];
			$luong = $row["Luong"];
			$phong = $row["Phong"];
			
			$data = $data. 
					"<tr>
						<td>$manv</td>
						<td>$hoten</td>
						<td>$ngaysinh</td>
						<td>$diachi</td>
						<td>$phai</td>
						<td>$luong</td>
						<td>$phong</td>
					</tr>";
        }
    }
    $mysqli->close();

	return "<table border='1'>$data</table>";
}

$POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA']) 
                ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
// $server->service($POST_DATA);
@$server->service(file_get_contents("php://input"));
exit();
?>