<?php

//Khai báo và cài đặt các hàm Webservice
function Search($keyword) {
    
	//return "ABC".$name;
	// 1. Ket noi CSDL
	$connection = mysql_connect("localhost","root","");
	mysql_select_db("nhanviendb", $connection);

	// 2. Chuan bi cau truy van & 3. Thuc thi cau truy van
	$strSQL = "SELECT * FROM NhanVien WHERE HoTen LIKE '%$keyword%'";
	
	$result = mysql_query($strSQL);


	// 4.Xu ly du lieu tra ve
	$data = "";
	$data = $data."<tr>
					<th>MANV</th>
					<th>Họ tên</th>
					<th>Ngày sinh</th>
					<th>Địa chỉ</th>
					<th>Điện thoại</th>
					<th>Mã khoa</th>
				   </tr>";
	while ($row = mysql_fetch_array($result))
	{
		$manv = $row["MaNV"];
		$hoten = $row["HoTen"];
		$ngaysinh = $row["NgaySinh"];
		$diachi = $row["DiaChi"];
		$phai = $row["Phai"];
		$luong = $row["Luong"];
		$phong = $row["Phong"];
		
		$data = $data. 
				"<tr>
					<td>$manv</td>
					<td>$hoten</td>
					<td>$ngaysinh</td>
					<td>$diachi</td>
					<td>$phai</td>
					<td>$luong</td>
					<td>$phong</td>
				</tr>";
	}
	// 5. Dong ket noi
	mysql_close($connection);
	return "<table border='1'>$data</table>";
}

echo search("a");

?>