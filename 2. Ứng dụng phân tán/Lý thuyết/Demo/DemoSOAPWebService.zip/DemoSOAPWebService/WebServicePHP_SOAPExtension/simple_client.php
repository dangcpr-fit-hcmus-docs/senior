<?php
$client = new SoapClient(null, array(
  'location' => "http://localhost:8899/DemoSOAPWebService/WebServicePHP_SOAPExtension/simple_server.php",
  'uri'      => "urn://tyler/req"));

//Call echoo webservice
$echo = "ABC";
print ($client->
	__soapCall("echoo",array($echo)));
	
print "<br/>";
//Call add webservice
$x = 344;
$y = 223;		
print($client->__call( "add", array(new SoapParam($x, "a"),
									new SoapParam($y, "b"))));

?>
