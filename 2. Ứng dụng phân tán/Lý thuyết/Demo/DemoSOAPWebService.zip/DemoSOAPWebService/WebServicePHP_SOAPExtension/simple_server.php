<?php

function echoo($echo){
    return "ECHO: ".$echo;
}

function add($a, $b)
{
	return $a + $b;
}

$server = new SoapServer(null,
                         array('uri' => "urn://tyler/res"));
						 
$server->addFunction('echoo');
$server->addFunction('add');

$server->handle();

?>