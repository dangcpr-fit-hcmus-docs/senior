﻿<?php

error_reporting(E_ERROR | E_PARSE);	 
include('../libs/nusoap.php');

$client = new nusoap_client('http://localhost:8899/DemoSOAPWebService/WebservicePHP_DemoNuSOAP_Reverse/Provider/service.php?wsdl', true);

$ketqua = $client->call('Reverse', array('text' => "Hello World !"));

echo "Kết quả  : <b style='color:red;font-size:25px'>".$ketqua."</b>";
?>