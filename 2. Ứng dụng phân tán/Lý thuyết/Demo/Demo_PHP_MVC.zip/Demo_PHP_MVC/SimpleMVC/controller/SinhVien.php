<?php

class SinhVienController
{
    public function layDanhSach()
    {
        $data = SinhVienModel::layDanhSach();
        $x = 10;
        require("view/DanhSachSV.php");
    }
}
?>
