<hr/>
<?php
//echo $x;
foreach ($data as $item) 
{
    echo $item . "<br/>";
}
?>
