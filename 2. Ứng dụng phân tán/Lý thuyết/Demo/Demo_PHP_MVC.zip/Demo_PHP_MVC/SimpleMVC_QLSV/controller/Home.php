<?php

class HomeController
{
    public function index()
    {
        $data = "Hello world !!!!";        
        require("./view/TrangChu.php");
    }
}
