<?php

class SinhVienController
{
    public function listAll()
    {
        $data = SinhVienModel::listAll();        
        require("./view/DanhSachSV.php");
    }
    
    public function search($keyword)
    {
        $data = SinhVienModel::find($keyword);
        require("./view/DanhSachSV.php");
    }
    
    public function add()
    {
        if (isset($_REQUEST["MSSV"]))
        {
            $sv = new SinhVienModel();
            $sv->MSSV = $_REQUEST["MSSV"];
            $sv->HOTEN = $_REQUEST["HoTen"];
            $sv->NGAYSINH = $_REQUEST["NgaySinh"];
            $sv->DIACHI = $_REQUEST["DiaChi"];
            $sv->DIENTHOAI = $_REQUEST["DienThoai"];
            $sv->MAKHOA = $_REQUEST["MaKhoa"];
            $result = SinhVienModel::add($sv);
            if ($result == 1)
                $data = "Thêm thành công";
            else
                $data = "Thêm bị lỗi";        
        }
        require("./view/ThemSV.php");
    }
}
?>
