<?php
require_once("./controller/Home.php");
require_once("./controller/SinhVien.php");
require_once("./model/SinhVien.php");

$action = "";
if (isset($_REQUEST["action"]))
{    
    $action = $_REQUEST["action"];
}
 
switch ($action)
{
    case "list":      
        $controller = new SinhVienController();
        $controller->listAll();
        break;
    case "search":
        $controller = new SinhVienController();
        $keyword = $_REQUEST["keyword"];
        $controller->search($keyword);
        break;
    case "add":
        $controller = new SinhVienController();
        $controller->add();
        break;
        
    default:
        $controller = new HomeController();
        $controller->index();
        break;
}


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
