<?php

class SinhVienModel
{
    public $MSSV;
    public $HOTEN;
    public $NGAYSINH;
    public $DIACHI;
    public $DIENTHOAI;
    public $MAKHOA;

    function __construct() {
        $this->MSSV = "";
        $this->MSSV = "";
    }
   
    public static function listAll() {
        require_once("config/dbconnect.php");
        
        $mysqli->query("SET NAMES utf8");
        $query = "SELECT * FROM SINHVIEN";
        $result = $mysqli->query($query);
        $dssv = array();
        if ($result) 
        {            
            foreach ($result as $row) {
                $sv = new SinhVienModel();
                $sv->HOTEN = $row["HoTen"];
                $sv->MSSV = $row["MSSV"];     
                $dssv[] = $sv; //add an item into array
            }
        }
        $mysqli->close();
        return $dssv;
    }
    
    public static function add($sv)
    {
        require_once("config/dbconnect.php");
        
        $mysqli->query("SET NAMES utf8");

        $mssv = $sv->MSSV;
        $hoten = $sv->HOTEN;
        $ngaysinh = $sv->NGAYSINH;
        $diachi = $sv->DIACHI;
        $dienthoai = $sv->DIENTHOAI;
        $makhoa = $sv->MAKHOA;

        $query = "INSERT INTO SINHVIEN values ($mssv, '$hoten', '$ngaysinh', '$diachi', '$dienthoai', '$makhoa')";
        
        if ($mysqli->query($query))        
            return 1;        
        return 0;
    }

    public static function find($keyword) {
        require_once("config/dbconnect.php");
        
        $mysqli->query("SET NAMES utf8");
        $query = "SELECT * FROM SINHVIEN WHERE HoTen LIKE '%$keyword%'";
        $result = $mysqli->query($query);
        $dssv = array();
        if ($result) 
        {            
            foreach ($result as $row) {
                $sv = new SinhVienModel();
                $sv->HOTEN = $row["HoTen"];
                $sv->MSSV = $row["MSSV"];     
                $dssv[] = $sv; //add an item into array
            }
        }
        $mysqli->close();
        return $dssv;
    }
}
?>
