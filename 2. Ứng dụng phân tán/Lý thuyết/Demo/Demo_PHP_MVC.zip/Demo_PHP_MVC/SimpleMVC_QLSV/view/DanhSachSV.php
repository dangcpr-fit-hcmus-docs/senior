<h1>DANH SÁCH SINH VIÊN</h1>
<hr/>

<form action="Index.php" method="get">
    <input type="hidden" name="action" value="search"/>
    <input type="text" name="keyword"/>        
    <input type="submit" value="search"/>
</form>

<?php
foreach ($data as $item) 
{    
    print ($item->MSSV . " " . $item->HOTEN . "<br/>");
}

?>

<a href="Index.php">Trang chủ</a>
