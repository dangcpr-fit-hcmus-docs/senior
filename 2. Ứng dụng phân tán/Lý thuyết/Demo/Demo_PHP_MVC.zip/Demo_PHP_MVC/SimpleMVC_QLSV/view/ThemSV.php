<h1>Thêm sinh viên </h1>
<form method ="post">
 	<input type="hidden" name="action" value="add" />
    <table>
        <tr>
            <td>Mã sinh viên</td>
            <td><input name="MSSV" type="text" /></td>
        </tr>
        <tr>
            <td>Họ và tên</td>
            <td><input name="HoTen" type="text" /></td>                   
        </tr>
        <tr>
            <td>Ngày Sinh</td>
            <td><input name="NgaySinh" type="text" /></td>
        </tr>
        <tr>
            <td>Địa chỉ</td>
            <td><input name="DiaChi" type="text" /></td>
        </tr>
        <tr>
            <td>Địa chỉ</td>
            <td><input name="DienThoai" type="text" /></td>
        </tr>
        <tr>
            <td>Mã Khoa</td>
            <td><input id="Text5" name="MaKhoa" type="text" /></td>
        </tr>                
    </table>
    <input type="submit" name="btnAddNewRecord" value="Thêm Sinh Viên Mới" />

    <?php
        if(isset($data))
        {
            echo $data;
        }
    ?>
</form>