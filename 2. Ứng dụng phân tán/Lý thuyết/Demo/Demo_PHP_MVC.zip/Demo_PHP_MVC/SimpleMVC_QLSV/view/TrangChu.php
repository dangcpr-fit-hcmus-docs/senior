<h1>TRANG CHỦ</h1>
<hr/>
<?php echo $data;?>
<ul>
    <li><a href="index.php?action=list">Xem danh sách sinh viên</a></li>
    <li><a href="index.php?action=add">Thêm sinh viên mới</a></li>
</ul>