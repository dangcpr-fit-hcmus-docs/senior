#!/usr/bin/env python
from flask import Flask
from flask import jsonify, request
app = Flask(__name__)

from mysql.connector import (connection)
def connect():
    cnx = connection.MySQLConnection(user='root', password='root',
                                     host='127.0.0.1',
                                     port='8889',
                                     database='SinhVienDB')
    return cnx


@app.route('/')
def hello_world():
   return ("Hello World")



@app.route('/hello1')
def hello1():
    data = {
        "message": "hello"
    }
    return jsonify(data)


@app.route('/hello2', methods=['GET'])
def hello2():
    data = {
        "message": "hello " + request.args.get('name')
    }
    return jsonify(data)


@app.route('/find', methods=['GET'])
def search_students():
    keyword = request.args.get('q', "")
    cnx = connect()
    cursor = cnx.cursor()
    query = (
        "SELECT * FROM SINHVIEN "
        "WHERE HoTen LIKE %s")

    cursor.execute(query, (keyword + '%',))
    data = []
    for t in cursor:
        data.append(t)
    cursor.close()
    cnx.close()
    return jsonify(data)


if __name__ == '__main__':
   app.run(port=5001)
